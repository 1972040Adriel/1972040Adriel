<?php
echo "<h1>Book Page</h1>";
$command = filter_input(INPUT_GET, 'tok');
if(isset($command) && $command == 'del') {
    $deleteIsbn = filter_input(INPUT_GET, 'did');
    if(isset($deleteIsbn)) {
        $link = new PDO("mysql:host=localhost; dbname=demo_pw220211", "root", "");
        $link->setAttribute(PDO::ATTR_AUTOCOMMIT, false);
        $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $query = "DELETE FROM book WHERE isbn = ?";
        $stmt = $link->prepare($query);
        $stmt->bindParam(1, $deleteIsbn, PDO::PARAM_STR);
        $link->beginTransaction();
        if($stmt->execute()) {
            $link->commit();
        } else {
            $link->rollBack();
        }
        $link = null;
    }
}

$submitted = filter_input(INPUT_POST, 'btnSubmitBook');
if($submitted) {
    $isbn = filter_input(INPUT_POST, 'txtIsbn');
    $title = filter_input(INPUT_POST, 'txtTitle');
    $author = filter_input(INPUT_POST, 'txtAuthor');
    $publisher = filter_input(INPUT_POST, 'txtPub');
    $description = filter_input(INPUT_POST, 'txtDes');
    $cover = filter_input(INPUT_POST, 'txtCover');
    $gendreId = filter_input(INPUT_POST, 'txtGendreId');
    $link = new PDO("mysql:host=localhost; dbname=demo_pw220211", "root", "");
    $link->setAttribute(PDO::ATTR_AUTOCOMMIT, false);
    $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $query = "INSERT INTO book(isbn, title, author, publisher, description, cover, genre_id) VALUES(?,?,?,?,?,?,?)";
    $stmt = $link->prepare($query);
    $stmt->bindParam(1, $isbn, PDO::PARAM_STR);
    $stmt->bindParam(2, $title, PDO::PARAM_STR);
    $stmt->bindParam(3, $author, PDO::PARAM_STR);
    $stmt->bindParam(4, $publisher, PDO::PARAM_STR);
    $stmt->bindParam(5, $description, PDO::PARAM_STR);
    $stmt->bindParam(6, $cover, PDO::PARAM_STR);
    $stmt->bindParam(7, $gendreId, PDO::PARAM_INT);
    $link->beginTransaction();
    if($stmt->execute()) {
        $link->commit();
    } else {
        $link->rollBack();
    }
    $link = null;
}
?>

<form action="" method="post">
    <label for="isbn">ISBN</label>
    <input type="text" id="isbn" name="txtIsbn" placeholder="isbn" maxlengyh="100"></br>
    <label for="title">Title</label>
    <input type="text" id="title" name="txtTitle" placeholder="title book" maxlengyh="100"></br>
    <label for="author">Author</label>
    <input type="text" id="author" name="txtAuthor" placeholder="author" maxlengyh="100"></br>
    <label for="publisher">Publisher</label>
    <input type="text" id="publisher" name="txtPub" placeholder="publisher" maxlengyh="100"></br>
    <label for="description">Description</label>
    <input type="text" id="description" name="txtDes" placeholder="description" maxlengyh="100"></br>
    <label for="cover">Cover</label>
    <input type="text" id="cover" name="txtCover" placeholder="cover" maxlengyh="100"></br>
    <label for="gendreId">Genre ID</label>
    <input type="text" id="gendreId" name="txtGendreId" placeholder="genre id" maxlengyh="100"></br>
    <input type="submit" value="Submit" name="btnSubmitBook">
</form>

<table>
    <thead>
        <th>ISBN</th>
        <th>Title</th>
        <th>Author</th>
        <th>Publisher</th>
        <th>Description</th>
        <th>Cover</th>
        <th>Genre_ID</th>
        <th>Action</th>
    </thead>
    <tbody>
        <?php
        $link = new PDO("mysql:host=localhost; dbname=demo_pw220211", "root", "");
        $link->setAttribute(PDO::ATTR_AUTOCOMMIT, false);
        $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $query = "SELECT isbn, title, author, publisher, description, cover, genre_id FROM book";
        $books = $link->query($query);
        foreach($books as $book) {
            echo "<tr>";
            echo "<td>" . $book['isbn'] . "</td>";
            echo "<td>" . $book['title'] . "</td>";
            echo "<td>" . $book['author'] . "</td>";
            echo "<td>" . $book['publisher'] . "</td>";
            echo "<td>" . $book['description'] . "</td>";
            echo "<td>" . $book['cover'] . "</td>";
            echo "<td>" . $book['genre_id'] . "</td>";
            echo "<td><button onclick='editBook(" . $book['isbn']. ")'>Edit</button>
            <button onclick='deleteBook(" . $book['isbn']. ")'>Delete</button></td>";
            echo "</tr>";
        }
        $link = null;
        ?>
    </tbody>
</table>