function deleteGenre(id){
    let confirmation = window.confirm("Are you sure want to delete");
    if (confirmation){
        window.location = "?mn=genre&tok=del&did=" + id;
    }
}

function deleteBook(isbn){
    let conf = window.confirm("Are you sure want to delete");
    if (conf){
        window.location = "?mn=book&tok=del&did=" + isbn;
    }
}

const editGenre = (id) => {
    window.location = "?mn=genre_update&uid=" + id;
}

const editBook = (isbn) => {
    window.location = "?mn=book_update&uid=" + isbn;
}